package strategy;

import model.FileStats;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

class FileStatsNumberWordsStrategyTest {

    private FileStatsStrategy fileStatsStrategy;


    @Test
    public void shouldGetQuantityWordsWhenIsOnlyOneLine() {
        //given
        fileStatsStrategy = new FileStatsNumberWordsStrategy();
        String line1 = "Hello world again!";
        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1));


        //when
        Integer count = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(count, 3);
    }

    @Test
    public void shouldNotGetQuantityWordsWhenIsOnlyOneLineAndIsEmpty() {
        //given
        fileStatsStrategy = new FileStatsNumberWordsStrategy();
        String line1 = "";
        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1));


        //when
        Integer count = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(count, 0);
    }

    @Test
    public void shouldGetQuantityWordsWhenIsOnlyMoreThanOneLineAndAreNotEmpty() {
        //given
        fileStatsStrategy = new FileStatsNumberWordsStrategy();
        String line1 = "Some";
        String line2 = "people are good";
        String line3 = "some others too good";

        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1, line2, line3));


        //when
        Integer count = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(count, 8);
    }

    @Test
    public void shouldGetQuantityFullStopWhenIsMoreThanOneLineAndAreNotEmpty() {
        //given
        fileStatsStrategy = new FileStatsFullStopStrategy();
        String line1 = "Some.";
        String line2 = "people... are good";
        String line3 = "some others.. too good";

        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1, line2, line3));


        //when
        Integer count = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(count, 6);
    }

    @Test
    public void shouldNotGetQuantityFullStopWhenIsOnlyOneLineAndIsEmpty() {
        //given
        fileStatsStrategy = new FileStatsFullStopStrategy();
        String line1 = "";
        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1));


        //when
        Integer count = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(count, 0);
    }

    @Test
    public void shouldGetQuantityFullStopWhenIsOnlyOneLine() {
        //given
        fileStatsStrategy = new FileStatsFullStopStrategy();
        String line1 = "Hello world again...!";
        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1));


        //when
        Integer count = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(count, 3);
    }

    @Test
    public void shouldGetWordMostUsedWhenIsOnlyOneLine() {
        //given
        fileStatsStrategy = new FileStatsMostUsedWordStrategy();
        String line1 = "Hello Hello world world again...!";
        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1));


        //when
        String word = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(word, "world");
    }

    @Test
    public void shouldNotGetMostUsedWordWhenIsOnlyOneLineAndIsEmpty() {
        //given
        fileStatsStrategy = new FileStatsMostUsedWordStrategy();
        String line1 = "";
        FileStats fileStats = new FileStats("some.txt", Arrays.asList(line1));


        //when
        String word = fileStatsStrategy.applyStats(fileStats);

        //then
        assertEquals(word, "");
    }
}