package strategy;


import model.FileStats;

import java.util.Arrays;

public class FileStatsNumberWordsStrategy implements FileStatsStrategy {
    @Override
    public <T> T applyStats(FileStats fileStats) {
        Integer count = new Integer(String.valueOf(fileStats.getContent().stream().filter(str -> !str.equals("")).flatMap(str -> Arrays.stream(str.split(" "))).count()));
        System.out.println("The quantity of words is: " + count);
        return (T) count;
    }

}
