package strategy;

import model.FileStats;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class FileStatsMostUsedWordStrategy implements FileStatsStrategy {
    @Override
    public <T> T applyStats(FileStats fileStats) {
        String content = fileStats.getContent().stream().reduce("", String::concat);
        String[] words = content.split(" ");
        String wordMax = findMostUsedWord(populateWordQuantityMap(words));
        System.out.println("The word most used is: " + wordMax);
        return (T) wordMax;
    }

    private String findMostUsedWord(Map<String, Integer> wordMap) {
        Map.Entry<String, Integer> maxEntry = null;
        for (Map.Entry<String, Integer> entry : wordMap.entrySet()) {
            if (maxEntry == null || entry.getValue() > maxEntry.getValue()) {
                maxEntry = entry;
            }
        }
        return maxEntry.getKey();
    }

    private Map<String, Integer> populateWordQuantityMap(String[] words) {
        Map<String, Integer> wordsMap = new HashMap<>();
        for (String word: words) {
            if(!wordsMap.containsKey(word)) {
                wordsMap.put(word, 1);
            } else {
                wordsMap.compute(word, (k, v) -> v + 1);
            }
        }

        return wordsMap;
    }
}
