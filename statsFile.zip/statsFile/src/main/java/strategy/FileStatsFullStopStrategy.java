package strategy;


import model.FileStats;

public class FileStatsFullStopStrategy implements FileStatsStrategy {
    @Override
    public <T> T applyStats(FileStats fileStats) {
        String content = fileStats.getContent().stream().reduce("", String::concat);
        Integer count = Integer.parseInt(String.valueOf(content.chars().filter(ch -> ch == '.').count()));
        System.out.println("The quantity of FullStop is: " + count);
        return (T) count;
    }
}
