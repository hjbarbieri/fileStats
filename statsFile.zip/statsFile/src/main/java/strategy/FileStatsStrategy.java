package strategy;

import model.FileStats;

public interface FileStatsStrategy {

    <T> T applyStats(FileStats fileStats);
}
