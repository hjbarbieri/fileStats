package service;

public class FileStatsDocServiceImpl extends FileStatsServiceImpl {
}
