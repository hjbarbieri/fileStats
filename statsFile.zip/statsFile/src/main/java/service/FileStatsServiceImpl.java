package service;

import model.FileStats;
import strategy.FileStatsStrategy;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.List;

public class FileStatsServiceImpl implements FileStatsService {

    public FileStats process(String path) throws IOException {
        FileStats fileStats = new FileStats();
        fileStats.setTitle(Paths.get(path).getFileName().toString());
        List<String> lines = Files.readAllLines(Paths.get(path));
        fileStats.setContent(lines);
        return fileStats;
    }

    public void runStrategy(FileStats fileStats, FileStatsStrategy fileStatsStrategy) {
        fileStatsStrategy.applyStats(fileStats);
    }

    public void moveFile(FileStats fileStats, String path, String processedPath) throws IOException {
        Files.move(Paths.get(path), Paths.get(processedPath + "/" + fileStats.getTitle()), StandardCopyOption.REPLACE_EXISTING);
    }

}
