package service;

import model.FileStats;
import strategy.FileStatsStrategy;

import java.io.IOException;

public interface FileStatsService {
    FileStats process(String path) throws IOException;
    void runStrategy(FileStats fileStats, FileStatsStrategy fileStatsStrategy);
    void moveFile(FileStats fileStats, String path, String processedPath) throws IOException;
}
