package model;

import java.util.List;

public class FileStats {

    private String title;
    private List<String> content;

    public FileStats() {

    }

    enum FILE_TYPE  {PDF, DOC, CSV}

    public FileStats(String title, List<String> content) {
        this.title = title;
        this.content = content;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getContent() {
        return content;
    }

    public void setContent(List<String> content) {
        this.content = content;
    }
}
