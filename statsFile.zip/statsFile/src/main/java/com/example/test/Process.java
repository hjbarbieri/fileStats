package com.example.test;

import model.FileStats;
import org.apache.commons.io.FilenameUtils;
import service.FileStatsService;
import service.FileStatsServiceImpl;
import strategy.FileStatsFullStopStrategy;
import strategy.FileStatsMostUsedWordStrategy;
import strategy.FileStatsNumberWordsStrategy;

import javax.xml.xpath.XPath;
import java.io.IOException;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;

public class Process {

    public static void main(String[] args) {
        String pathHardcoded = "C:\\Users\\hugo.barbieri\\Documents";
        try(WatchService service = FileSystems.getDefault().newWatchService()) {
             Map<WatchKey, Path> keyMap = new HashMap<>();
            Path path = Paths.get(pathHardcoded);
            keyMap.put(path.register(service,
                    StandardWatchEventKinds.ENTRY_CREATE),
                    path);
            WatchKey watchKey;

            do {
                watchKey = service.take();
                Path eventDir = keyMap.get(watchKey);
                for (WatchEvent<?> event: watchKey.pollEvents()) {
                    WatchEvent.Kind<?> kind = event.kind();
                    Path eventPath = (Path) event.context();
                    processFile(eventDir, eventPath);
                    System.out.println(eventDir + ": " + kind + " :" +  eventPath );
                }

            } while (watchKey.reset());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void processFile(Path eventDir, Path eventPath) throws IOException {
        String extension = FilenameUtils.getExtension(eventPath.getFileName().toString());
        FileStatsService fileStatsService = null;
        switch (extension) {
            case "txt" : {
                fileStatsService =  new FileStatsServiceImpl();
            }
            //case "doc" : {fileStatsService =  new service.FileStatsDocServiceImpl(); }

        }
        if(fileStatsService != null){
            String path = eventDir + "\\" + eventPath.getFileName().toString();
            String processedPath = "C:\\Users\\hugo.barbieri\\Documents\\processed";
            FileStats process = fileStatsService.process(path);

            fileStatsService.runStrategy(process, new FileStatsNumberWordsStrategy());
            fileStatsService.runStrategy(process, new FileStatsFullStopStrategy());
            fileStatsService.runStrategy(process, new FileStatsMostUsedWordStrategy());

            fileStatsService.moveFile(process, path, processedPath);

        }

    }
}
